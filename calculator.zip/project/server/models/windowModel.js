/**
 * Class to manage a sliding window of numbers
 */
export class NumberWindow {
  /**
   * Creates a new NumberWindow instance
   * @param {number} size - The maximum number of items in the window
   */
  constructor(size = 10) {
    this.size = size;
    this.numbers = [];
  }

  /**
   * Resizes the window, maintaining the most recent numbers
   * @param {number} newSize - The new window size
   */
  resize(newSize) {
    if (newSize < 1) {
      throw new Error('Window size must be at least 1');
    }
    
    this.size = newSize;
    
    // If current numbers exceed the new size, trim the oldest numbers
    if (this.numbers.length > newSize) {
      this.numbers = this.numbers.slice(this.numbers.length - newSize);
    }
  }

  /**
   * Adds new numbers to the window, maintaining uniqueness and window size
   * @param {number[]} newNumbers - Array of numbers to add
   */
  addNumbers(newNumbers) {
    if (!Array.isArray(newNumbers)) {
      throw new Error('New numbers must be an array');
    }

    // Process each new number
    for (const num of newNumbers) {
      // Skip if the number already exists in the window
      if (!this.numbers.includes(num)) {
        // Add the new number
        this.numbers.push(num);
        
        // If the window exceeds the maximum size, remove the oldest number
        if (this.numbers.length > this.size) {
          this.numbers.shift();
        }
      }
    }
  }

  /**
   * Gets the current numbers in the window
   * @returns {number[]} - Array of numbers in the window
   */
  getNumbers() {
    return [...this.numbers];
  }

  /**
   * Calculates the average of the numbers in the window
   * @returns {number} - The average value or 0 if window is empty
   */
  getAverage() {
    if (this.numbers.length === 0) {
      return 0;
    }
    
    const sum = this.numbers.reduce((acc, num) => acc + num, 0);
    return sum / this.numbers.length;
  }
}