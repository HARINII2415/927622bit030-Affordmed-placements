import axios from 'axios';

// Base URL for the third-party API
const API_BASE_URL = 'http://20.244.56.144/evaluation-service';

// Map number IDs to their respective endpoints
const ENDPOINTS = {
  p: '/primes',    // prime numbers
  f: '/fibo',      // fibonacci numbers
  e: '/even',      // even numbers
  r: '/rand'       // random numbers
};

/**
 * Fetches numbers from the third-party API based on the number ID
 * @param {string} numberId - The ID of the number type (p, f, e, r)
 * @returns {Promise<number[]>} - Array of numbers fetched from the API
 */
export async function fetchNumbers(numberId) {
  try {
    // Get the endpoint for the given number ID
    const endpoint = ENDPOINTS[numberId];
    
    if (!endpoint) {
      throw new Error(`Invalid number ID: ${numberId}`);
    }
    
    // Make the API request
    const response = await axios.get(`${API_BASE_URL}${endpoint}`);
    
    // Extract and return the numbers from the response
    if (response.data && Array.isArray(response.data.numbers)) {
      return response.data.numbers;
    } else {
      throw new Error('Invalid response format from third-party API');
    }
  } catch (error) {
    console.error(`Error fetching ${numberId} numbers:`, error);
    
    // For demo purposes, return mock data if the API call fails
    return getMockData(numberId);
  }
}

/**
 * Provides mock data in case the API is unavailable
 * @param {string} numberId - The ID of the number type (p, f, e, r)
 * @returns {number[]} - Mock array of numbers
 */
function getMockData(numberId) {
  switch (numberId) {
    case 'p': // prime numbers
      return [2, 3, 5, 7, 11, 13, 17, 19];
    case 'f': // fibonacci numbers
      return [1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    case 'e': // even numbers
      return [2, 4, 6, 8, 10, 12, 14, 16, 18, 20];
    case 'r': // random numbers
      return [7, 15, 23, 42, 18, 9, 31, 27, 14, 36];
    default:
      return [];
  }
}