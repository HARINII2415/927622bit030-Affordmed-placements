import express from 'express';
import cors from 'cors';
import { fetchNumbers } from './services/apiService.js';
import { NumberWindow } from './models/windowModel.js';

const app = express();
const PORT = process.env.PORT || 9876;

// Enable CORS and JSON middleware
app.use(cors());
app.use(express.json());

// Create number windows for each type with default size 10
const windows = {
  p: new NumberWindow(10), // prime
  f: new NumberWindow(10), // fibonacci
  e: new NumberWindow(10), // even
  r: new NumberWindow(10)  // random
};

// API endpoint to handle number requests
app.get('/numbers/:numberId', async (req, res) => {
  try {
    const { numberId } = req.params;
    const windowSize = parseInt(req.query.windowSize) || 10;
    
    // Validate the number ID
    if (!['p', 'f', 'e', 'r'].includes(numberId)) {
      return res.status(400).json({ 
        error: 'Invalid number ID. Use p (prime), f (fibonacci), e (even), or r (random).' 
      });
    }

    // Update window size if needed
    if (windows[numberId].size !== windowSize) {
      windows[numberId].resize(windowSize);
    }

    // Fetch numbers from third-party API
    const fetchedNumbers = await fetchNumbers(numberId);
    
    // Store the previous state
    const windowPrevState = [...windows[numberId].getNumbers()];
    
    // Add new numbers to the window
    windows[numberId].addNumbers(fetchedNumbers);
    
    // Get the current state and calculate average
    const windowCurrState = windows[numberId].getNumbers();
    const avg = windows[numberId].getAverage();
    
    // Return the response
    return res.json({
      windowPrevState,
      windowCurrState,
      numbers: fetchedNumbers,
      avg: parseFloat(avg.toFixed(2))
    });
  } catch (error) {
    console.error('Error processing request:', error);
    return res.status(500).json({ 
      error: 'Internal server error',
      message: error.message 
    });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export default app;