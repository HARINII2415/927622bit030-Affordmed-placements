import React from 'react';
import { motion } from 'framer-motion';

interface NumberWindowProps {
  title: string;
  numbers: number[];
  icon?: React.ReactNode;
  highlight?: boolean;
}

const NumberWindow: React.FC<NumberWindowProps> = ({
  title,
  numbers,
  icon,
  highlight = false
}) => {
  return (
    <div 
      className={`rounded-lg overflow-hidden border ${
        highlight 
          ? 'border-blue-500/50 bg-blue-800/30 backdrop-blur-sm' 
          : 'border-blue-700/30 bg-blue-900/20 backdrop-blur-sm'
      }`}
    >
      <div className={`p-3 flex items-center justify-between border-b ${
        highlight ? 'border-blue-500/30' : 'border-blue-700/30'
      }`}>
        <h3 className="font-medium flex items-center">
          {icon && <span className="mr-2">{icon}</span>}
          {title}
        </h3>
        <span className="text-xs px-2 py-1 rounded bg-blue-800/50">
          Count: {numbers.length}
        </span>
      </div>
      
      <div className="p-4">
        {numbers.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {numbers.map((num, index) => (
              <motion.div
                key={`${num}-${index}`}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className={`px-3 py-1 rounded-full text-sm ${
                  highlight 
                    ? 'bg-blue-600/60 text-white' 
                    : 'bg-blue-800/40 text-blue-200'
                }`}
              >
                {num}
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center text-blue-400 py-4">
            No numbers in window
          </div>
        )}
      </div>
    </div>
  );
};

export default NumberWindow;