import React from 'react';
import { motion } from 'framer-motion';
import { NumberId } from '../types';
import { Activity, TrendingUp, ChevronRight } from 'lucide-react';

interface NumberVisualizerProps {
  prevState: number[];
  currState: number[];
  newNumbers: number[];
  average: number;
  selectedType: NumberId;
  getTypeLabel: (id: NumberId) => string;
}

const NumberVisualizer: React.FC<NumberVisualizerProps> = ({
  prevState,
  currState,
  newNumbers,
  average,
  selectedType,
  getTypeLabel
}) => {
  // Generate background color based on number type
  const getBgColor = () => {
    switch (selectedType) {
      case 'p': return 'from-blue-600/20 to-purple-600/20';
      case 'f': return 'from-green-600/20 to-teal-600/20';
      case 'e': return 'from-amber-600/20 to-orange-600/20';
      case 'r': return 'from-pink-600/20 to-red-600/20';
      default: return 'from-blue-600/20 to-purple-600/20';
    }
  };

  // Get accent color based on number type
  const getAccentColor = () => {
    switch (selectedType) {
      case 'p': return 'text-blue-400';
      case 'f': return 'text-green-400';
      case 'e': return 'text-amber-400';
      case 'r': return 'text-pink-400';
      default: return 'text-blue-400';
    }
  };

  return (
    <div className={`rounded-lg bg-gradient-to-r ${getBgColor()} border border-blue-500/30 backdrop-blur-sm p-6 overflow-hidden`}>
      <div className="flex flex-col md:flex-row items-center justify-between mb-6">
        <div className="mb-4 md:mb-0">
          <h2 className="text-xl font-semibold flex items-center">
            <Activity className={`h-5 w-5 mr-2 ${getAccentColor()}`} />
            {getTypeLabel(selectedType)} Numbers Visualization
          </h2>
          <p className="text-blue-300 text-sm">
            Window state transition and average calculation
          </p>
        </div>
        
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="flex items-center px-4 py-2 bg-blue-900/50 rounded-lg border border-blue-700/50"
        >
          <TrendingUp className={`h-5 w-5 mr-2 ${getAccentColor()}`} />
          <span className="font-mono font-semibold text-lg">
            Average: {average}
          </span>
        </motion.div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
        {/* Previous Window State */}
        <div className="md:col-span-5">
          <h3 className="text-sm text-blue-300 mb-2">Previous Window State</h3>
          <div className="bg-blue-900/30 rounded-lg p-3 border border-blue-700/30 min-h-16">
            {prevState.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {prevState.map((num, i) => (
                  <motion.span
                    key={`prev-${num}-${i}`}
                    initial={{ opacity: 0.5 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="inline-block px-2 py-1 text-xs bg-blue-800/50 rounded-md"
                  >
                    {num}
                  </motion.span>
                ))}
              </div>
            ) : (
              <div className="text-center text-blue-400 py-2 text-sm">
                Empty window
              </div>
            )}
          </div>
        </div>
        
        {/* Transition */}
        <div className="md:col-span-2 flex justify-center">
          <div className="flex flex-col items-center">
            <ChevronRight className="h-6 w-6 text-blue-400" />
            <div className="mt-1 px-2 py-1 bg-blue-800/40 rounded text-xs">
              Update
            </div>
          </div>
        </div>
        
        {/* Current Window State */}
        <div className="md:col-span-5">
          <h3 className="text-sm text-blue-300 mb-2">Current Window State</h3>
          <div className="bg-blue-800/30 rounded-lg p-3 border border-blue-500/30 min-h-16">
            {currState.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {currState.map((num, i) => {
                  const isNew = !prevState.includes(num);
                  return (
                    <motion.span
                      key={`curr-${num}-${i}`}
                      initial={{ scale: isNew ? 0.5 : 1, opacity: isNew ? 0 : 1 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ duration: 0.5, delay: isNew ? i * 0.1 : 0 }}
                      className={`inline-block px-2 py-1 text-xs rounded-md ${
                        isNew 
                          ? 'bg-blue-600/70 text-white' 
                          : 'bg-blue-800/50 text-blue-100'
                      }`}
                    >
                      {num}
                    </motion.span>
                  );
                })}
              </div>
            ) : (
              <div className="text-center text-blue-400 py-2 text-sm">
                Empty window
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* New Numbers */}
      <div className="mt-6 pt-4 border-t border-blue-700/30">
        <h3 className="text-sm text-blue-300 mb-2">Newly Fetched Numbers</h3>
        <div className="bg-blue-900/20 rounded-lg p-3 border border-blue-700/20">
          {newNumbers.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {newNumbers.map((num, i) => (
                <motion.span
                  key={`new-${num}-${i}`}
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ duration: 0.3, delay: i * 0.05 }}
                  className={`inline-block px-2 py-1 text-xs rounded-md ${getAccentColor()} bg-blue-900/40`}
                >
                  {num}
                </motion.span>
              ))}
            </div>
          ) : (
            <div className="text-center text-blue-400 py-2 text-sm">
              No new numbers fetched
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NumberVisualizer;