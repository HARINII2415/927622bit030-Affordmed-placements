import React from 'react';
import { NumberResponse, NumberId } from '../types';
import { Code } from 'lucide-react';

interface ResponseCardProps {
  response: NumberResponse;
  selectedType: NumberId;
  getTypeLabel: (id: NumberId) => string;
}

const ResponseCard: React.FC<ResponseCardProps> = ({
  response,
  selectedType,
  getTypeLabel
}) => {
  // Format the response as a JSON string
  const jsonString = JSON.stringify(response, null, 2);

  return (
    <div className="bg-blue-900/30 rounded-lg border border-blue-700/30 overflow-hidden">
      <div className="p-3 flex items-center justify-between border-b border-blue-700/30">
        <h3 className="font-medium flex items-center">
          <Code className="h-5 w-5 mr-2" />
          API Response for {getTypeLabel(selectedType)} Numbers
        </h3>
      </div>
      
      <div className="overflow-x-auto">
        <pre className="text-xs md:text-sm p-4 text-blue-200 font-mono">
          {jsonString}
        </pre>
      </div>
    </div>
  );
};

export default ResponseCard;