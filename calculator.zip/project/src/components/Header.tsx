import React from 'react';
import { Activity } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-blue-900 border-b border-blue-700 shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-600 rounded-lg">
              <Activity className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-white">
                Average Calculator
              </h1>
              <p className="text-blue-300 text-sm hidden md:block">
                HTTP Microservice for Number Analysis
              </p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-2">
            <div className="px-3 py-1 bg-blue-800/50 rounded-full text-sm text-blue-200 border border-blue-700/50">
              <span className="inline-block h-2 w-2 rounded-full bg-green-400 mr-2"></span>
              API Connected
            </div>
            <div className="px-3 py-1 bg-blue-800/50 rounded-full text-sm text-blue-200 border border-blue-700/50">
              Window Size: 10
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;