import React, { useState } from 'react';
import { Settings, RefreshCw } from 'lucide-react';
import { NumberId, SettingsType } from '../types';

interface ControlPanelProps {
  selectedType: NumberId;
  onTypeChange: (type: NumberId) => void;
  settings: SettingsType;
  onSettingsChange: (settings: Partial<SettingsType>) => void;
  loading: boolean;
  getTypeIcon: (id: NumberId) => React.ReactNode;
  getTypeLabel: (id: NumberId) => string;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  selectedType,
  onTypeChange,
  settings,
  onSettingsChange,
  loading,
  getTypeIcon,
  getTypeLabel
}) => {
  const [showSettings, setShowSettings] = useState(false);

  const numberTypes: NumberId[] = ['p', 'f', 'e', 'r'];

  return (
    <div className="bg-blue-800/20 backdrop-blur-sm rounded-lg border border-blue-500/30 overflow-hidden">
      <div className="p-4 border-b border-blue-700/50">
        <h2 className="text-lg font-semibold text-white flex items-center">
          <Settings className="h-5 w-5 mr-2" />
          Control Panel
        </h2>
      </div>
      
      <div className="p-4">
        <div className="mb-6">
          <label className="block text-sm font-medium text-blue-300 mb-2">
            Select Number Type
          </label>
          <div className="grid grid-cols-2 gap-2">
            {numberTypes.map((type) => (
              <button
                key={type}
                onClick={() => onTypeChange(type)}
                className={`flex items-center justify-center p-3 rounded-md transition-all ${
                  selectedType === type
                    ? 'bg-blue-600 text-white'
                    : 'bg-blue-800/30 text-blue-300 hover:bg-blue-700/50'
                }`}
              >
                {getTypeIcon(type)}
                <span className="ml-2">{getTypeLabel(type)}</span>
              </button>
            ))}
          </div>
        </div>
        
        <div className="mb-6">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="w-full flex items-center justify-between p-3 rounded-md bg-blue-800/30 text-blue-300 hover:bg-blue-700/50 transition-all"
          >
            <span className="flex items-center">
              <Settings className="h-5 w-5 mr-2" />
              Window Settings
            </span>
            <span className="text-xs bg-blue-700/50 px-2 py-1 rounded">
              Size: {settings.windowSize}
            </span>
          </button>
          
          {showSettings && (
            <div className="mt-3 p-4 bg-blue-900/50 rounded-md">
              <div className="mb-4">
                <label htmlFor="windowSize" className="block text-sm font-medium text-blue-300 mb-1">
                  Window Size
                </label>
                <input
                  id="windowSize"
                  type="number"
                  min="1"
                  max="100"
                  value={settings.windowSize}
                  onChange={(e) => onSettingsChange({ windowSize: parseInt(e.target.value) || 10 })}
                  className="w-full p-2 bg-blue-800/30 border border-blue-700 rounded-md text-white"
                />
              </div>
              
              <div className="mb-4">
                <div className="flex items-center">
                  <input
                    id="autoRefresh"
                    type="checkbox"
                    checked={settings.autoRefresh}
                    onChange={(e) => onSettingsChange({ autoRefresh: e.target.checked })}
                    className="h-4 w-4 text-blue-600 rounded border-blue-700 bg-blue-800/30 focus:ring-blue-500"
                  />
                  <label htmlFor="autoRefresh" className="ml-2 block text-sm text-blue-300">
                    Auto Refresh
                  </label>
                </div>
              </div>
              
              {settings.autoRefresh && (
                <div className="mb-2">
                  <label htmlFor="refreshInterval" className="block text-sm font-medium text-blue-300 mb-1">
                    Refresh Interval (ms)
                  </label>
                  <select
                    id="refreshInterval"
                    value={settings.refreshInterval}
                    onChange={(e) => onSettingsChange({ refreshInterval: parseInt(e.target.value) })}
                    className="w-full p-2 bg-blue-800/30 border border-blue-700 rounded-md text-white"
                  >
                    <option value={2000}>2 seconds</option>
                    <option value={5000}>5 seconds</option>
                    <option value={10000}>10 seconds</option>
                    <option value={30000}>30 seconds</option>
                  </select>
                </div>
              )}
            </div>
          )}
        </div>
        
        <button
          onClick={() => onTypeChange(selectedType)}
          disabled={loading}
          className={`w-full flex items-center justify-center p-3 rounded-md transition-all ${
            loading
              ? 'bg-blue-700/50 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-500'
          }`}
        >
          <RefreshCw className={`h-5 w-5 mr-2 ${loading ? 'animate-spin' : ''}`} />
          {loading ? 'Fetching...' : 'Fetch Numbers'}
        </button>
      </div>
    </div>
  );
};

export default ControlPanel;