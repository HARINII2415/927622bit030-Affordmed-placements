import React from 'react';
import { Github, Code } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-blue-900 border-t border-blue-700 py-4">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-4 md:mb-0 text-center md:text-left">
            <p className="text-blue-300 text-sm">
              Average Calculator HTTP Microservice &copy; {new Date().getFullYear()}
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <a
              href="#"
              className="text-blue-300 hover:text-white transition-colors flex items-center"
            >
              <Code className="h-4 w-4 mr-1" />
              <span className="text-sm">API Docs</span>
            </a>
            <a
              href="#"
              className="text-blue-300 hover:text-white transition-colors flex items-center"
            >
              <Github className="h-4 w-4 mr-1" />
              <span className="text-sm">GitHub</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;