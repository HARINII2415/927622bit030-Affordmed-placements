import React, { useState, useEffect } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Calculator, BarChart4, LineChart, RotateCcw, Settings } from 'lucide-react';
import Header from './components/Header';
import ControlPanel from './components/ControlPanel';
import NumberWindow from './components/NumberWindow';
import NumberVisualizer from './components/NumberVisualizer';
import ResponseCard from './components/ResponseCard';
import { fetchNumberData } from './services/apiService';
import { NumberResponse, NumberId, SettingsType } from './types';
import Footer from './components/Footer';

function App() {
  const [settings, setSettings] = useState<SettingsType>({
    windowSize: 10,
    autoRefresh: false,
    refreshInterval: 5000,
  });
  
  const [selectedType, setSelectedType] = useState<NumberId>('p');
  const [loading, setLoading] = useState<boolean>(false);
  const [response, setResponse] = useState<NumberResponse | null>(null);

  // Handle auto-refresh
  useEffect(() => {
    let interval: number | undefined;
    
    if (settings.autoRefresh) {
      interval = window.setInterval(() => {
        fetchData(selectedType);
      }, settings.refreshInterval);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [settings.autoRefresh, settings.refreshInterval, selectedType]);

  const fetchData = async (numberId: NumberId) => {
    setLoading(true);
    
    try {
      const data = await fetchNumberData(numberId, settings.windowSize);
      setResponse(data);
      
      // Show success message
      toast.success(`Successfully fetched ${getTypeLabel(numberId)} numbers`);
    } catch (error) {
      console.error('Error fetching data:', error);
      
      // Show error message
      toast.error('Failed to fetch data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getTypeLabel = (id: NumberId): string => {
    switch (id) {
      case 'p': return 'Prime';
      case 'f': return 'Fibonacci';
      case 'e': return 'Even';
      case 'r': return 'Random';
      default: return 'Unknown';
    }
  };

  const handleTypeChange = (id: NumberId) => {
    setSelectedType(id);
    fetchData(id);
  };

  const handleSettingsChange = (newSettings: Partial<SettingsType>) => {
    setSettings({ ...settings, ...newSettings });
    
    // If window size changed, fetch new data
    if (newSettings.windowSize && newSettings.windowSize !== settings.windowSize) {
      fetchData(selectedType);
    }
  };

  const getTypeIcon = (id: NumberId) => {
    switch (id) {
      case 'p': return <Calculator className="h-5 w-5" />;
      case 'f': return <LineChart className="h-5 w-5" />;
      case 'e': return <BarChart4 className="h-5 w-5" />;
      case 'r': return <RotateCcw className="h-5 w-5" />;
      default: return <Calculator className="h-5 w-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-blue-900 text-white flex flex-col">
      <ToastContainer position="top-right" theme="dark" />
      
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <ControlPanel 
              selectedType={selectedType}
              onTypeChange={handleTypeChange}
              settings={settings}
              onSettingsChange={handleSettingsChange}
              loading={loading}
              getTypeIcon={getTypeIcon}
              getTypeLabel={getTypeLabel}
            />
          </div>
          
          <div className="lg:col-span-2 space-y-8">
            {response ? (
              <>
                <NumberVisualizer 
                  prevState={response.windowPrevState}
                  currState={response.windowCurrState}
                  newNumbers={response.numbers}
                  average={response.avg}
                  selectedType={selectedType}
                  getTypeLabel={getTypeLabel}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <NumberWindow 
                    title="Previous Window State"
                    numbers={response.windowPrevState}
                    icon={<Settings className="h-5 w-5" />}
                  />
                  
                  <NumberWindow 
                    title="Current Window State"
                    numbers={response.windowCurrState}
                    icon={getTypeIcon(selectedType)}
                    highlight
                  />
                </div>
                
                <ResponseCard response={response} selectedType={selectedType} getTypeLabel={getTypeLabel} />
              </>
            ) : (
              <div className="flex items-center justify-center h-64 bg-blue-800/20 backdrop-blur-sm rounded-lg border border-blue-500/30">
                <div className="text-center p-8">
                  <Calculator className="h-16 w-16 mx-auto mb-4 text-blue-400" />
                  <h2 className="text-xl font-semibold mb-2">No Data Available</h2>
                  <p className="text-blue-300 mb-4">Select a number type to fetch data from the API</p>
                  <button
                    onClick={() => fetchData(selectedType)}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-md transition-colors"
                  >
                    Fetch {getTypeLabel(selectedType)} Numbers
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

export default App;