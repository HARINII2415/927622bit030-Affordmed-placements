export type NumberId = 'p' | 'f' | 'e' | 'r';

export interface NumberResponse {
  windowPrevState: number[];
  windowCurrState: number[];
  numbers: number[];
  avg: number;
}

export interface SettingsType {
  windowSize: number;
  autoRefresh: boolean;
  refreshInterval: number;
}