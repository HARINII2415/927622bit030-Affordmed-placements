import { NumberId, NumberResponse } from '../types';
import axios from 'axios';

// API base URL - Update to use the correct port
const API_URL = 'http://localhost:9876';

/**
 * Fetches number data from the API
 * @param numberId The type of numbers to fetch (p, f, e, r)
 * @param windowSize The window size to use
 * @returns Promise with the number response data
 */
export async function fetchNumberData(
  numberId: NumberId, 
  windowSize: number = 10
): Promise<NumberResponse> {
  try {
    const response = await axios.get<NumberResponse>(
      `${API_URL}/numbers/${numberId}`, 
      { params: { windowSize } }
    );
    
    return response.data;
  } catch (error) {
    console.error('Error fetching number data:', error);
    throw error;
  }
}

export { fetchNumberData }